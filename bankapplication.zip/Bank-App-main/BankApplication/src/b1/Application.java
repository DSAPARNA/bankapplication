package b1;

import java.util.*;
public class Application {
	Account allAccounts[] = new Account[10000000];
	int noOfAccountEntry = 0;
	
	Scanner obj1 = new Scanner(System.in);
	Scanner obj2 = new Scanner(System.in);
	public static void main(String[] args) {
		
		Application bankApp = new Application();
	
	
	while(true)
	{
		System.out.println("1. Submit User Details. ");
		System.out.println("2. Do Deposite Operation. ");
		System.out.println("3. Do Withdrawl Operation. ");
		System.out.println("4. Print user all details. ");
		System.out.println("5. Print user contact details. ");
		System.out.println("6. Print KYC document details. ");
		System.out.println("7. Print Balance. ");
		System.out.println("8. Change mobile number. ");
		System.out.println("9. Change email id. ");
		
		System.out.println("0. EXIT");
		
		System.out.println(" Enter option [0-9] :- ");
		
		switch (new Scanner(System.in).nextInt()) {
		
		case 0:
			System.exit(0);
			break;

		case 1:
			bankApp.submitUserDetails();
			break;
			
		case 2:
			bankApp.deposite();
			break;
		
		case 3:
			bankApp.withdrawl();
			break;
		
		case 4:
			bankApp.userDetails();
			break;
		
		case 5:
			bankApp.contactDetails();
			break;
		case 6:
			bankApp.kycDetails();
			break;
		case 7:
			bankApp.balance();
			break;
		case 8:
			bankApp.changeMobileNumber();
			break;
		case 9:
			bankApp.changeEmailId();
			break;	
			
			
			
		default:
			System.out.println("Invalid Option ...");
		} //end switch
	}
}


	public void submitUserDetails() {
		Random myRandom = new Random();
		long AccountNumber = myRandom.nextInt();
		System.out.println("Enter User Name: ");
		String userName = obj2.nextLine();
		System.out.println("Enter Password: ");
		String password = obj2.nextLine();
		System.out.println("Enter Balance: ");
		int balance = obj1.nextInt();
		System.out.println("Enter Pan Number: ");
		String panNumber = obj2.nextLine();
		System.out.println("Enter Aadhar Number: ");
		long aadharNumber = obj1.nextInt();
		System.out.println("Enter Document Type: ");
		String documentType = obj2.nextLine();
		System.out.println("Enter Document Number: ");
		String documentNumber = obj2.nextLine();
		System.out.println("Enter House Number: ");
		String houseNumber = obj2.nextLine();
		System.out.println("Enter Locality: ");
		String localityName = obj2.nextLine();
		System.out.println("Enter City: ");
		String cityName = obj2.nextLine();
		System.out.println("Enter State: ");
		String stateName = obj2.nextLine();
		System.out.println("Enter Country: ");
		String countryName = obj2.nextLine();
		System.out.println("Enter Pin Code: ");
		long pinCode = obj1.nextInt();
		System.out.println("Enter Mobile Number: ");
		long mobileNumber = obj1.nextInt();
		System.out.println("Enter Email id: ");
		long emailId = obj1.nextInt();
		
		
		ContactDetails contactDetails = new ContactDetails (houseNumber,localityName,cityName,stateName,countryName,pinCode,mobileNumber,emailId);
		KYCVerification kycVerification = new KYCVerification(panNumber,aadharNumber,documentType,documentNumber);
		Account details= new Account(accountNumber, userName, password,balance, balance);
		
		details.setKycdetails(kycVerification);
		details.setContactDetails(contactDetails);
		int noOfAccounts = 0;
		allAccounts[noOfAccounts++]=a;
		System.out.println(""+a);
		System.out.println("Added in the list.");
	}


	public void deposite() {
		System.out.println("Enter account number : ");
		int enteredNumber = obj1.nextInt();
		
		System.out.println(" Enter Amount to be deposite :-  ");
		int amount  = obj1.nextInt();
		
		Account enteredAccount = null;
		boolean foundEnteredAccount = false;
		
		for(int i = 0; i< noOfAccountEntry; i++)
		{
			Account a = allAccounts[i];
			if(a.getAccountNumber()== enteredNumber)
			{
				enteredAccount = a;
				foundEnteredAccount = true;
			}
			if(foundEnteredAccount)
			{
				enteredAccount.setBalance(enteredAccount.getBalance()+amount);
			}
		}
		
		
		
		System.out.println(" Deposite Done ");
		System.out.println(" Cheack Balance ");
		System.out.println(enteredAccount.getAccountNumber()+" - "+enteredAccount.getBalance());
		
	}


	public void withdrawl() {
		System.out.println("Enter account number : ");
		int enteredNumber = obj1.nextInt();
		
		System.out.println(" Enter Amount to be withdrawl :-  ");
		int amount  = obj1.nextInt();
		
		Account enteredAccount = null;
		boolean foundEnteredAccount = false;
		
		for(int i = 0; i< noOfAccountEntry; i++)
		{
			Account a = allAccounts[i];
			if(a.getAccountNumber()== enteredNumber)
			{
				enteredAccount = a;
				foundEnteredAccount = true;
			}
			if(foundEnteredAccount)
			{
				enteredAccount.setBalance(enteredAccount.getBalance()-amount);
			}
		}	
		System.out.println(" Withdrawl Done ");
		System.out.println(" Cheack Balance ");
		System.out.println(enteredAccount.getAccountNumber()+" - "+enteredAccount.getBalance());
			
		
	}


	public void userDetails() {
		System.out.println("Enter the account Number : ");
		long searchAccNum = obj1.nextInt();
		
		Account a = get.Account(searchAccNum);
		System.out.println(a);
		
		
	}


	private Account get.Account(long searchAccNum) {
		for (int i =0; i<noOfAccountEntry;i++)
		{
			Account[] enteredAccount = null;
			Account a = enteredAccount[i];
			boolean isFound = (a.getAccountNumber()== searchAccNum?true:false);
		}	
		boolean isFound = false;
		if(isFound)
		{
			Account a = null;
			return a;
		}
		return null;
	}


	public void contactDetails() {
		System.out.println("Enter the account Number : ");
		long searchAccNum = obj1.nextInt();
		
		Account a = get.Account(searchAccNum);
		System.out.println(a.getContactDetails());
		
	}


	public void kycDetails() {
		System.out.println("Enter the account Number : ");
		long searchAccNum = obj1.nextInt();
		
		Account a = get.Account(searchAccNum);
		System.out.println(a.getKycdetails());
		
	}


	public void balance() {
		System.out.println("Enter the account Number : ");
		long searchAccNum = obj1.nextInt();
		
		Account a = get.Account(searchAccNum);
		System.out.println(a.getBalance());
		
	}


	public void changeMobileNumber() {
		System.out.println("Enter the account Number : ");
		long searchAccNum = obj1.nextInt();
		
		Account a = get.Account(searchAccNum);
		long preMobNum = a.getContactDetails().getMobileNumber();
		System.out.println(preMobNum);
		
		System.out.println("Enter Mobile Number :");
		long mobNum = obj1.nextInt();
		a.getContactDetails().setMobileNumber(mobNum);
		System.out.println("Mobile Number"+a.getContactDetails().getMobileNumber());
		
	}


	public void changeEmailId() {
		System.out.println("Enter the account Number : ");
		long searchAccNum = obj1.nextInt();
		
		Account a = get.Account(searchAccNum);
		long preEmailId = a.getContactDetails().getEmailId();
		System.out.println(preEmailId);
		
		System.out.println("Enter Email Id: ");
		long email = obj1.nextInt();
		a.getContactDetails().setEmailId(email);
		System.out.println("Email ID"+a.getContactDetails().getEmailId());
		
		
	}
}	
