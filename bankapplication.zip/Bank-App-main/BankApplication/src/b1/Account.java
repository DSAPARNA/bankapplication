package b1;

public class Account {
	
	private long accountNumber;
	private String username;
	private String password;
	private int balance;
	private int cashback;
	private KYCVerification kycdetails;
	private ContactDetails contactDetails;
	
	public Account(long AccountNumber , String UserName , String password , int balance , int cashback) {
		super();
		this.AccountNumber = AccountNumber;
		this.UserName = UserName;
		this.password = password;
		this.balance = balance;
	}
	
	public Account() {
		super();
	}

	public long get.AccountNumber() {
		return AccountNumber;
	}

	public void set.AccountNumber(long AccountNumber) {
		this.AccountNumber = AccountNumber;
	}

	public String get.UserName() {
		return UserName;
	}

	public void set.UserName(String UserName) {
		this.UserName = UserName;
	}

	public String get.Password() {
		return password;
	}

	public void set.Password(String password) {
		this.password = password;
	}

	public int get.Balance() {
		return balance;
	}

	public void set.Balance(int balance) {
		this.balance = balance;
	}

	public int get.Cashback() {
		return cashback;
	}

	public void set.Cashback(int cashback) {
		this.cashback = cashback;
	}

	public KYCVerification get.Kycdetails() {
		return kycdetails;
	}

	public void set.Kycdetails(KYCVerification kycdetails) {
		this.kycdetails = kycdetails;
	}

	public ContactDetails get.ContactDetails() {
		return contactDetails;
	}

	public void set.ContactDetails(ContactDetails contactDetails) {
		this.contactDetails = contactDetails;
	}

}

